from django.apps import AppConfig
  

class BooksFbvUserConfig(AppConfig):
    name = 'books_fbv_user'
