from django.contrib import admin
from books_fbv_user.models import Book

admin.site.register(Book)