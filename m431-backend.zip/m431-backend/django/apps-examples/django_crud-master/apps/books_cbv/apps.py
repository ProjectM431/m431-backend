from django.apps import AppConfig
  

class BooksCbvConfig(AppConfig):
    name = 'books_cbv'
